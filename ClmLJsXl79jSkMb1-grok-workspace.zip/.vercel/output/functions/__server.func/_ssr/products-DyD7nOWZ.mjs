import { Y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as PRODUCTS } from "./products-BJeAk_c_.mjs";
import { t as PageHeader } from "./page-header-BqS1Qee4.mjs";
import { t as ProductCard } from "./product-card-DrAM6qIJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/products-DyD7nOWZ.js
var import_jsx_runtime = require_jsx_runtime();
function ProductsIndex() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, { title: "Our products" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "py-16 md:py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-site",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-2xl text-base leading-relaxed text-muted",
				children: "Custom-fitted uPVC doors and windows, aluminium partitions, invisible grills, window blinds, and ceiling cloth hangers — fabricated and installed in Hyderabad. Mosquito-mesh systems are not part of this range."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3",
				children: PRODUCTS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product: p }, p.slug))
			})]
		})
	})] });
}
//#endregion
export { ProductsIndex as component };
