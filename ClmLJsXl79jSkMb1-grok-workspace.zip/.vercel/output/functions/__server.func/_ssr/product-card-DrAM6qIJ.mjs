import { Y as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { h as ArrowUpRight } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/product-card-DrAM6qIJ.js
var import_jsx_runtime = require_jsx_runtime();
function ProductCard({ product }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/products/$slug",
		params: { slug: product.slug },
		className: "group block overflow-hidden rounded-xl border border-line bg-surface shadow-lift transition-[transform,box-shadow] duration-200 hover:-translate-y-0.5 hover:shadow-soft",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative aspect-[4/3] overflow-hidden bg-cream",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: product.thumb,
				alt: product.name,
				className: "size-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute right-3 top-3 inline-flex size-9 items-center justify-center rounded-full bg-paper text-brand opacity-0 shadow-lift transition-opacity duration-200 group-hover:opacity-100",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-4" })
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-semibold uppercase tracking-[0.18em] text-accent",
					children: product.eyebrow
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-1 font-display text-2xl font-medium text-brand",
					children: product.shortName
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-relaxed text-muted",
					children: product.summary
				})
			]
		})]
	});
}
//#endregion
export { ProductCard as t };
