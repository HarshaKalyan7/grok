//#region node_modules/.nitro/vite/services/ssr/assets/products-BJeAk_c_.js
var PRODUCTS = [
	{
		slug: "upvc-doors-windows",
		name: "uPVC Doors and Windows",
		shortName: "uPVC Doors & Windows",
		eyebrow: "Energy-efficient openings",
		summary: "Superior strength, weather resistance, and modern aesthetics for homes and commercial spaces.",
		description: "uPVC (Unplasticized Polyvinyl Chloride) doors and windows are designed for long-lasting performance, excellent insulation, and low maintenance. They balance durability, style, and everyday function — rust-proof, termite-resistant, and built for Hyderabad’s heat, rain, and humidity.",
		image: "/images/upvc-doors-windows.webp",
		thumb: "/images/our-products/upvc-doors-windows.webp",
		gallery: [
			"/images/upvc-doors-windows.webp",
			"/images/our-products/upvc-doors-windows.webp",
			"/images/sliders/slider-1.webp",
			"/images/about-image-1.webp"
		],
		features: [
			"Strong and weather-resistant uPVC frames",
			"Excellent thermal and sound insulation",
			"Rust-proof and termite-resistant material",
			"Smooth operation with durable hardware",
			"Easy to clean and low maintenance",
			"Available in multiple designs and finishes"
		],
		benefits: [
			{
				title: "Improves energy efficiency and comfort",
				body: "Excellent insulation helps maintain indoor temperature and everyday comfort."
			},
			{
				title: "Reduces outside noise",
				body: "Minimizes external noise for a quieter, more peaceful indoor environment."
			},
			{
				title: "Withstands harsh weather",
				body: "Resists heat, rain, and humidity without warping or corrosion."
			},
			{
				title: "Enhances security and durability",
				body: "Strong frames and reliable hardware for safety and long-lasting performance."
			},
			{
				title: "Holds its finish",
				body: "Retains appearance over time with very little upkeep."
			}
		],
		uses: [
			"Residential homes and apartments",
			"Villas and independent houses",
			"Offices and commercial buildings",
			"Showrooms and retail spaces",
			"Hospitals, schools, and institutions"
		],
		cta: "Upgrade your space with uPVC excellence"
	},
	{
		slug: "aluminium-partitions",
		name: "Aluminium Partitions",
		shortName: "Aluminium Partitions",
		eyebrow: "Smart space division",
		summary: "Stylish, practical partitions that divide space while keeping light, openness, and a contemporary finish.",
		description: "Aluminium partitions are lightweight yet strong systems for dividing interiors efficiently. They deliver a clean, modern finish and can be customised for homes, offices, and commercial spaces — without permanent structural changes.",
		image: "/images/aluminium-partitions.webp",
		thumb: "/images/our-products/aluminium-partitions.webp",
		gallery: [
			"/images/aluminium-partitions.webp",
			"/images/our-products/aluminium-partitions.webp",
			"/images/our-approach-image.webp",
			"/images/about-image-2.webp"
		],
		features: [
			"Strong and lightweight aluminium frames",
			"Sleek, modern design",
			"Rust-resistant and durable material",
			"Easy to clean and maintain",
			"Custom sizes and layouts",
			"Quick installation with minimal disruption"
		],
		benefits: [
			{
				title: "Creates organised, functional rooms",
				body: "Smartly divides interiors to improve space efficiency while staying open."
			},
			{
				title: "Enhances interior aesthetics",
				body: "A sleek finish that complements contemporary homes and offices."
			},
			{
				title: "Lets light travel",
				body: "Keeps spaces bright by allowing natural light across divided areas."
			},
			{
				title: "Durable and long-lasting",
				body: "High-quality aluminium for strength, stability, and years of use."
			},
			{
				title: "Flexible and customisable",
				body: "Sizes, layouts, and finishes tailored to your space."
			}
		],
		uses: [
			"Offices and workspaces",
			"Commercial buildings",
			"Homes and apartments",
			"Showrooms and retail spaces",
			"Clinics, salons, and studios"
		],
		cta: "Transform your space with smart partitions"
	},
	{
		slug: "invisible-grills",
		name: "Invisible Grills",
		shortName: "Invisible Grills",
		eyebrow: "Safety without the bars",
		summary: "High-tensile stainless steel balcony and window protection that keeps the view open.",
		description: "Invisible grills are modern safety systems made from strong stainless steel cables, tensioned in slim frames. They protect balconies, windows, and high-rise openings without the closed-in look of traditional iron bars — so children and pets stay safe, and the city view stays yours.",
		image: "/images/invisible-grills.webp",
		thumb: "/images/our-products/invisible-grills.webp",
		gallery: [
			"/images/invisible-grills.webp",
			"/images/our-products/invisible-grills.webp",
			"/images/sliders/slider-3.webp",
			"/images/about-image-3.webp"
		],
		features: [
			"High-tensile stainless steel cables",
			"Does not block the outside view",
			"Allows full sunlight and airflow",
			"Modern, discreet appearance",
			"Strong fall protection for balconies",
			"Precision tensioning by trained technicians"
		],
		benefits: [
			{
				title: "Better balcony safety",
				body: "A secure barrier that helps prevent children and pets from falling, without boxing in the balcony."
			},
			{
				title: "Clear outside view",
				body: "Cables are slim and nearly invisible from a short distance — enjoy the city, not the bars."
			},
			{
				title: "Modern home appearance",
				body: "Matches contemporary apartments and keeps openings looking open and styled."
			},
			{
				title: "Weather-ready materials",
				body: "Stainless cables resist rust and outdoor weather in Hyderabad."
			},
			{
				title: "Clean professional fitting",
				body: "Neat installation without damaging walls or balcony structure."
			}
		],
		uses: [
			"Apartment balconies",
			"High-rise buildings",
			"Windows in tall buildings",
			"Staircase openings",
			"Terrace railings",
			"French windows"
		],
		cta: "Protect your family without losing the view"
	},
	{
		slug: "ceiling-cloth-hangers",
		name: "Ceiling Cloth Hangers",
		shortName: "Cloth Hangers",
		eyebrow: "Vertical drying, clear floors",
		summary: "Durable ceiling-mounted hangers that keep clothes organised and neatly out of the way.",
		description: "Ceiling cloth hangers are suspended systems installed from the ceiling to hold garments and drying clothes. They save floor space, reduce clutter, and put unused vertical space to work — ideal for homes, laundry rooms, and hospitality.",
		image: "/images/ceiling-cloth-hangers.webp",
		thumb: "/images/our-products/ceiling-cloth-hanger.webp",
		gallery: [
			"/images/ceiling-cloth-hangers.webp",
			"/images/our-products/ceiling-cloth-hanger.webp",
			"/images/how-it-work-image-1.webp"
		],
		features: [
			"Durable metal construction for long-lasting use",
			"Space-saving ceiling-mounted design",
			"Adjustable height — raise or lower as needed",
			"Easy installation in homes and laundry rooms",
			"Holds multiple garments securely",
			"Smooth lifting and lowering mechanism"
		],
		benefits: [
			{
				title: "Maximises floor space",
				body: "Keeps rooms tidy by moving drying and storage off the floor."
			},
			{
				title: "Protects garments",
				body: "Proper hanging helps prevent wrinkles and damage."
			},
			{
				title: "Effortless drying and storage",
				body: "Ideal for daily laundry and wardrobe overflow."
			},
			{
				title: "Versatile use",
				body: "Works in homes, apartments, hotels, and commercial spaces."
			},
			{
				title: "Long-lasting performance",
				body: "Quality materials built for repeated everyday use."
			}
		],
		uses: [
			"Home closets and dressing rooms",
			"Laundry and drying areas",
			"Hotels, resorts, and hospitality",
			"Commercial storage or retail displays"
		],
		cta: "Elevate your storage solutions"
	},
	{
		slug: "window-blinds",
		name: "Window Blinds",
		shortName: "Window Blinds",
		eyebrow: "Light, privacy, finish",
		summary: "Custom-fitted blinds that dress the window, control sunlight, and add privacy — in styles for every room.",
		description: "Premium window blinds for homes and workplaces in Hyderabad. They add finish, control sun and glare, and can be opened for air or closed for privacy. We offer roller, vertical, venetian, wooden, and zebra (day & night) blinds, custom-fitted to your openings.",
		image: "/images/window-blinds-695b40585315a.webp",
		thumb: "/images/our-products/window-blinds.webp",
		gallery: [
			"/images/window-blinds-695b40585315a.webp",
			"/images/our-products/window-blinds.webp",
			"/images/sliders/slider-2.webp",
			"/images/about-image-2.webp"
		],
		features: [
			"Wide range of designs, patterns, and colours",
			"Custom fitted to your exact window size",
			"Smooth, easy operation",
			"Child-safer design options",
			"Free repair support for chains, fabric, and tracks",
			"Professional installation by trained technicians"
		],
		benefits: [
			{
				title: "Natural sunlight control",
				body: "Let morning light in, or limit glare and heat when the sun is high."
			},
			{
				title: "Privacy without losing the view",
				body: "Choose openness or seclusion without heavy curtains."
			},
			{
				title: "Energy saving",
				body: "Controlling heat gain can reduce the load on air conditioning."
			},
			{
				title: "Easy everyday use",
				body: "Mechanisms designed to run smoothly for everyone in the home."
			},
			{
				title: "Child safety and security",
				body: "Safer designs around children, plus extra privacy when you need it."
			}
		],
		uses: [
			"Living rooms and bedrooms",
			"Offices and meeting rooms",
			"Kitchens and utility windows",
			"Showrooms and clinics"
		],
		cta: "Make over your windows with lasting blinds"
	}
];
var BLIND_PRICES = [
	{
		type: "Roller blinds",
		range: "₹90 – ₹250 / sq. ft"
	},
	{
		type: "Vertical blinds",
		range: "₹120 – ₹300 / sq. ft"
	},
	{
		type: "Venetian blinds",
		range: "₹110 – ₹350 / sq. ft"
	},
	{
		type: "Wooden blinds",
		range: "₹350 – ₹900 / sq. ft"
	},
	{
		type: "Zebra blinds",
		range: "₹180 – ₹450 / sq. ft"
	}
];
var BLIND_TYPES = [
	"Window blinds",
	"Zebra blinds (day & night)",
	"Wooden blinds",
	"Venetian blinds",
	"Roller blinds",
	"Vertical blinds"
];
function getProduct(slug) {
	return PRODUCTS.find((p) => p.slug === slug);
}
var PROCESS_STEPS = [
	{
		n: "01",
		title: "Book a free visit",
		body: "Schedule a quick appointment — our team visits your location to understand your needs."
	},
	{
		n: "02",
		title: "Measurement & demo",
		body: "We take precise measurements and show samples so you can choose the right finish and system."
	},
	{
		n: "03",
		title: "Custom fabrication",
		body: "Your selection is crafted to exact size using premium materials and accurate workshop fitting."
	},
	{
		n: "04",
		title: "Professional installation",
		body: "Trained technicians install neatly, with a clean finish and smooth everyday operation."
	},
	{
		n: "05",
		title: "After-sales support",
		body: "We stay connected with prompt service, maintenance help, and long-term product support."
	}
];
var FEATURES = [
	{
		title: "Rust-proof frames",
		body: "Premium aluminium and uPVC profiles that hold up in humidity and outdoor conditions."
	},
	{
		title: "Weather-ready build",
		body: "Systems designed for rain, dust, heat, and daily wear without losing strength."
	},
	{
		title: "Smooth operation",
		body: "Quality hardware and rollers for effortless open–close movement, year after year."
	},
	{
		title: "Child-safe & pet-safe",
		body: "Thoughtful edges, secure fitting, and balcony protection options for family homes."
	},
	{
		title: "Custom sizes",
		body: "Made to measure for any door, window, balcony, or interior opening."
	}
];
var WHY_US = [
	{
		title: "High-quality materials",
		body: "Premium-grade uPVC, aluminium, stainless cables, and durable hardware."
	},
	{
		title: "Affordable pricing",
		body: "Top-quality work at honest, pocket-friendly prices — no compromise on finish."
	},
	{
		title: "Professional installation",
		body: "Trained technicians for a precise fit, clean look, and reliable operation."
	},
	{
		title: "Long-lasting durability",
		body: "Built for daily use, weather, and wear — designed to last for years."
	},
	{
		title: "Customer support",
		body: "A team that’s available for queries, service, and maintenance."
	},
	{
		title: "Fast delivery & service",
		body: "Quick turnaround, timely installation, and efficient follow-up — every time."
	}
];
//#endregion
export { PRODUCTS as a, PROCESS_STEPS as i, BLIND_TYPES as n, WHY_US as o, FEATURES as r, getProduct as s, BLIND_PRICES as t };
