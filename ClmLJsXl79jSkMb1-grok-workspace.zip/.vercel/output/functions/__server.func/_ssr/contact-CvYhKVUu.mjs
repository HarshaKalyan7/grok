import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { Y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as mailtoUrl, i as cn, n as Button, o as telUrl, r as SITE, s as whatsappUrl, t as AREAS } from "./site-BIwBVyd5.mjs";
import { a as PRODUCTS } from "./products-BJeAk_c_.mjs";
import { i as Phone, o as MapPin, s as Mail } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as PageHeader } from "./page-header-BqS1Qee4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-CvYhKVUu.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-11 w-full rounded-md border border-line bg-surface px-3.5 text-sm text-ink-soft shadow-none transition-colors placeholder:text-muted/70 focus-visible:border-brand focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40 disabled:cursor-not-allowed disabled:opacity-50", className),
		ref,
		...props
	});
});
Input.displayName = "Input";
var Label = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
	ref,
	className: cn("text-xs font-semibold uppercase tracking-[0.14em] text-muted", className),
	...props
}));
Label.displayName = "Label";
var Textarea = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-32 w-full rounded-lg border border-line bg-surface px-3.5 py-3 text-sm text-ink-soft transition-colors placeholder:text-muted/70 focus-visible:border-brand focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40 disabled:cursor-not-allowed disabled:opacity-50", className),
		ref,
		...props
	});
});
Textarea.displayName = "Textarea";
function QuoteForm({ className }) {
	const [name, setName] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [product, setProduct] = (0, import_react.useState)("");
	const [message, setMessage] = (0, import_react.useState)("");
	function onSubmit(e) {
		e.preventDefault();
		if (!name.trim() || !phone.trim()) {
			toast.error("Please add your name and phone number.");
			return;
		}
		const lines = [
			`Hi, ${SITE.name} — I'd like a free quote.`,
			`Name: ${name.trim()}`,
			`Phone: ${phone.trim()}`,
			email.trim() ? `Email: ${email.trim()}` : null,
			product ? `Product: ${product}` : null,
			message.trim() ? `Message: ${message.trim()}` : null
		].filter(Boolean);
		window.open(whatsappUrl(lines.join("\n")), "_blank", "noopener,noreferrer");
		toast.success("Opening WhatsApp with your enquiry.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: cn("rounded-2xl border border-line bg-surface p-6 shadow-soft md:p-8", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-display text-2xl font-medium text-brand",
				children: "Reach out for a free consultation"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Share a few details and we’ll get back with a site visit and quote."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "quote-name",
							children: "Name"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "quote-name",
							name: "name",
							autoComplete: "name",
							value: name,
							onChange: (e) => setName(e.target.value),
							placeholder: "Your name",
							required: true
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2 sm:grid-cols-2 sm:gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "quote-phone",
								children: "Phone"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "quote-phone",
								name: "phone",
								type: "tel",
								autoComplete: "tel",
								value: phone,
								onChange: (e) => setPhone(e.target.value),
								placeholder: "Mobile number",
								required: true
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "quote-email",
								children: "Email"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "quote-email",
								name: "email",
								type: "email",
								autoComplete: "email",
								value: email,
								onChange: (e) => setEmail(e.target.value),
								placeholder: "Optional"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "quote-product",
							children: "Product"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							id: "quote-product",
							name: "product",
							value: product,
							onChange: (e) => setProduct(e.target.value),
							className: "flex h-11 w-full rounded-md border border-line bg-surface px-3.5 text-sm text-ink-soft focus-visible:border-brand focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "Select a product"
								}),
								PRODUCTS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: p.name,
									children: p.name
								}, p.slug)),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "Not sure yet",
									children: "Not sure yet"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "quote-message",
							children: "Message"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							id: "quote-message",
							name: "message",
							value: message,
							onChange: (e) => setMessage(e.target.value),
							placeholder: "Tell us about your doors, windows, or balcony…"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						size: "lg",
						className: "mt-2 w-full sm:w-auto",
						children: "Send on WhatsApp"
					})
				]
			})
		]
	});
}
function ContactPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, { title: "Contact us" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "py-16 md:py-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-site grid gap-10 lg:grid-cols-[0.9fr_1.1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-[0.2em] text-accent",
						children: "Visit or call"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-3xl font-medium text-brand md:text-4xl",
						children: "Let’s plan your openings"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-base leading-relaxed text-muted",
						children: "Free site visit, measurement, and quote across Hyderabad. Same workshop, same phone number — now focused on uPVC, partitions, invisible grills, blinds, and hangers."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-8 space-y-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "inline-flex size-11 shrink-0 items-center justify-center rounded-md bg-cream text-brand",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-semibold uppercase tracking-[0.16em] text-muted",
										children: "Our location"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm leading-relaxed text-ink",
										children: SITE.address
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: SITE.maps,
										target: "_blank",
										rel: "noreferrer",
										className: "mt-1 inline-block text-sm font-semibold text-brand hover:text-accent",
										children: "Open in Google Maps"
									})
								] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "inline-flex size-11 shrink-0 items-center justify-center rounded-md bg-cream text-brand",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold uppercase tracking-[0.16em] text-muted",
									children: "Call us"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: telUrl(),
									className: "mt-1 block text-sm font-semibold text-ink hover:text-brand",
									children: SITE.phoneDisplay
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "inline-flex size-11 shrink-0 items-center justify-center rounded-md bg-cream text-brand",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold uppercase tracking-[0.16em] text-muted",
									children: "Email us"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: mailtoUrl(),
									className: "mt-1 block text-sm font-semibold text-ink hover:text-brand",
									children: SITE.email
								})] })]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-10",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold uppercase tracking-[0.16em] text-muted",
							children: "Service areas"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-3 flex flex-wrap gap-2",
							children: AREAS.map((area) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "rounded-pill border border-line bg-surface px-3 py-1.5 text-xs font-medium text-ink",
								children: area
							}, area))
						})]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuoteForm, {})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "pb-16 md:pb-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "container-site overflow-hidden rounded-2xl border border-line",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
					title: "Custom UPVC Screens location in Quthbullapur, Hyderabad",
					src: SITE.mapsEmbed,
					className: "h-80 w-full border-0 md:h-[420px]",
					loading: "lazy",
					referrerPolicy: "no-referrer-when-downgrade"
				})
			})
		})
	] });
}
//#endregion
export { ContactPage as component };
