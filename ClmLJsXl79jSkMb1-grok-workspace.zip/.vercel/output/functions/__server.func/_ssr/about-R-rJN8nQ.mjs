import { Y as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Button, r as SITE } from "./site-BIwBVyd5.mjs";
import { o as WHY_US } from "./products-BJeAk_c_.mjs";
import { c as HeartHandshake, l as Eye, u as Compass } from "../_libs/lucide-react.mjs";
import { t as PageHeader } from "./page-header-BqS1Qee4.mjs";
import { t as SectionHeading } from "./section-heading-BXZxr8Fa.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-R-rJN8nQ.js
var import_jsx_runtime = require_jsx_runtime();
function AboutPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, { title: "About us" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "py-16 md:py-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-site grid items-start gap-12 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
						eyebrow: "About us",
						title: "Premium openings designed for beautiful, protected spaces",
						body: `At ${SITE.name}, we bring together quality craftsmanship and modern design to create long-lasting solutions for homes and offices. From uPVC doors and windows to invisible grills, aluminium partitions, blinds, and ceiling hangers, every product is built for durability, smooth operation, and everyday comfort.`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 text-base leading-relaxed text-muted",
						children: [
							"We are a dedicated team of professionals committed to high-quality work that meets your needs and exceeds expectations. With ",
							SITE.years,
							"+ years of experience in Hyderabad, we combine expertise, careful installation, and honest service."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/contact",
								children: "Get a free quote"
							})
						})
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figure", {
					className: "overflow-hidden rounded-2xl",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/images/our-approach-image.webp",
						alt: "Craftsman installing a custom window system",
						className: "aspect-[5/4] size-full object-cover"
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-cream py-16 md:py-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-site grid gap-6 md:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-xl border border-line bg-surface p-7",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: "size-7 text-accent" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-5 font-display text-2xl font-medium text-brand",
								children: "Our mission"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm leading-relaxed text-muted",
								children: "To provide stylish protection that enhances the way you live, while ensuring reliability, craftsmanship, and customer satisfaction in every solution we offer."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-xl border border-line bg-surface p-7",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-7 text-accent" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-5 font-display text-2xl font-medium text-brand",
								children: "Our vision"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm leading-relaxed text-muted",
								children: "To be the trusted name in custom uPVC and home opening solutions in Hyderabad — setting the standard for quality, finish, and service."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-xl border border-line bg-surface p-7",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeartHandshake, { className: "size-7 text-accent" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-5 font-display text-2xl font-medium text-brand",
								children: "Our values"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm leading-relaxed text-muted",
								children: "Honesty and transparency in all we do. Every product and installation should meet a high standard — measured twice, fitted once, supported after."
							})
						]
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "py-16 md:py-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-site",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					title: "Quality you can trust. Service you can rely on.",
					body: "The same workshop discipline, on-site care, and after-sales support our Hyderabad customers already know."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3",
					children: WHY_US.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-xl border border-line bg-surface p-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-lg font-semibold text-brand",
							children: item.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted",
							children: item.body
						})]
					}, item.title))
				})]
			})
		})
	] });
}
//#endregion
export { AboutPage as component };
