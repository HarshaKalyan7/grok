import { Y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as cn } from "./site-BIwBVyd5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/section-heading-BXZxr8Fa.js
var import_jsx_runtime = require_jsx_runtime();
function SectionHeading({ eyebrow, title, body, invert = false, align = "left" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("max-w-2xl", align === "center" && "mx-auto text-center"),
		children: [
			eyebrow ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("text-xs font-semibold uppercase tracking-[0.22em]", invert ? "text-accent" : "text-accent"),
				children: eyebrow
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: cn("mt-3 font-display text-3xl font-medium leading-tight tracking-tight md:text-4xl lg:text-[2.75rem]", invert ? "text-paper" : "text-brand"),
				children: title
			}),
			body ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("mt-4 text-base leading-relaxed", invert ? "text-paper/75" : "text-muted"),
				children: body
			}) : null
		]
	});
}
//#endregion
export { SectionHeading as t };
