import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { Y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/site-BIwBVyd5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-pill text-sm font-semibold tracking-tight transition-[transform,background-color,color,box-shadow,opacity] duration-200 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/70 focus-visible:ring-offset-2 focus-visible:ring-offset-paper disabled:pointer-events-none disabled:opacity-50 active:scale-[0.98] [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-accent text-ink hover:bg-brand hover:text-paper shadow-[0_10px_24px_-12px_rgb(210_160_60/0.8)]",
			brand: "bg-brand text-paper hover:bg-brand-deep",
			outline: "border border-line bg-surface text-ink hover:border-brand hover:text-brand",
			ghost: "text-ink hover:bg-cream",
			light: "bg-paper text-brand hover:bg-cream shadow-[0_8px_20px_-12px_rgb(0_0_0/0.35)]"
		},
		size: {
			default: "h-11 px-6",
			sm: "h-9 px-4 text-xs",
			lg: "h-12 px-8 text-base",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var SITE = {
	name: "Custom UPVC Screens",
	shortName: "Custom UPVC",
	tagline: "Premium uPVC doors, windows & home solutions in Hyderabad",
	phone: "+917660047005",
	phoneDisplay: "+91 76600 47005",
	email: "customscreens11@gmail.com",
	address: "Plot No. 2/A, Opp. Siemens CIE, Gandhi Nagar Road, Quthbullapur, Hyderabad, Telangana, India.",
	addressShort: "Quthbullapur, Hyderabad, Telangana",
	whatsapp: "917660047005",
	maps: "https://maps.app.goo.gl/RTP9akNqryqf3yY86",
	mapsEmbed: "https://maps.google.com/maps?q=Plot%20No.%202/A%2C%20Opp.%20Siemens%20CIE%2C%20Gandhi%20Nagar%20Road%2C%20Quthbullapur%2C%20Hyderabad&t=&z=15&ie=UTF8&iwloc=&output=embed",
	years: 25,
	city: "Hyderabad"
};
var AREAS = [
	"Quthbullapur",
	"Kukatpally",
	"Suchitra",
	"Jeedimetla",
	"Balanagar",
	"Bachupally",
	"Kompally",
	"Miyapur",
	"Pragathi Nagar",
	"All of Hyderabad"
];
function whatsappUrl(text) {
	const message = text ?? `Hi, ${SITE.name} — I'm interested in a free quote for the products you offer.`;
	return `https://api.whatsapp.com/send?phone=+${SITE.whatsapp}&text=${encodeURIComponent(message)}`;
}
function telUrl() {
	return `tel:${SITE.phone}`;
}
function mailtoUrl() {
	return `mailto:${SITE.email}`;
}
//#endregion
export { mailtoUrl as a, cn as i, Button as n, telUrl as o, SITE as r, whatsappUrl as s, AREAS as t };
