import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { Y as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as cn, n as Button, r as SITE } from "./site-BIwBVyd5.mjs";
import { a as PRODUCTS, i as PROCESS_STEPS, o as WHY_US, r as FEATURES } from "./products-BJeAk_c_.mjs";
import { g as ArrowRight, m as BadgeCheck, p as CalendarCheck, r as ShieldCheck } from "../_libs/lucide-react.mjs";
import { t as ProductCard } from "./product-card-DrAM6qIJ.mjs";
import { t as SectionHeading } from "./section-heading-BXZxr8Fa.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CpHdT2UP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SLIDES = [
	{
		image: "/images/sliders/slider-1.webp",
		eyebrow: "Elegant protection for every home",
		title: "Premium uPVC for modern living",
		body: "Upgrade your windows and doors with durable, stylish uPVC systems made to fit.",
		cta: "Explore products",
		to: "/products"
	},
	{
		image: "/images/sliders/slider-2.webp",
		eyebrow: "Comfort, light, and finish",
		title: "Blinds and openings built for daily use",
		body: "Custom-fitted blinds, partitions, and uPVC that look considered — and work every day.",
		cta: "View solutions",
		to: "/contact"
	},
	{
		image: "/images/sliders/slider-3.webp",
		eyebrow: "Smart safety for modern spaces",
		title: "Invisible grills. Open views.",
		body: "Protect balconies and windows without the look of heavy bars.",
		cta: "Get a free quote",
		to: "/contact"
	}
];
function HeroSlider() {
	const [index, setIndex] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => {
			setIndex((i) => (i + 1) % SLIDES.length);
		}, 6500);
		return () => window.clearInterval(id);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative isolate h-[calc(100dvh-4rem)] min-h-[560px] max-h-[820px] overflow-hidden bg-overlay md:h-[calc(100dvh-6.5rem)]",
		children: [
			SLIDES.map((slide, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("absolute inset-0 transition-opacity duration-700 ease-out", i === index ? "opacity-100" : "opacity-0"),
				"aria-hidden": i !== index,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: slide.image,
					alt: "",
					className: "size-full object-cover"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-[linear-gradient(90deg,rgb(20_12_4/0.78)_0%,rgb(20_12_4/0.45)_55%,rgb(20_12_4/0.18)_100%)]" })]
			}, slide.title)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "container-site relative flex h-full items-end pb-24 md:items-center md:pb-16",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold uppercase tracking-[0.22em] text-accent",
							children: SLIDES[index].eyebrow
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-3 font-display text-[2.15rem] font-medium leading-[1.12] tracking-tight text-paper sm:text-4xl md:text-6xl md:leading-[1.08]",
							children: SLIDES[index].title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-md text-sm leading-relaxed text-paper/80 md:mt-5 md:text-lg",
							children: SLIDES[index].body
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-6 md:mt-8",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "light",
								size: "lg",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: SLIDES[index].to,
									children: SLIDES[index].cta
								})
							})
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute bottom-20 left-1/2 z-10 flex -translate-x-1/2 gap-2 md:bottom-8",
				children: SLIDES.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": `Show slide ${i + 1}`,
					className: cn("h-2 rounded-pill transition-[width,background-color] duration-300", i === index ? "w-8 bg-accent" : "w-2 bg-paper/45 hover:bg-paper/80"),
					onClick: () => setIndex(i)
				}, s.title))
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroSlider, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "py-16 md:py-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-site grid items-center gap-12 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative mb-8 pb-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("figure", {
							className: "overflow-hidden rounded-xl",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/images/about-image-1.webp",
								alt: "uPVC window installation",
								className: "aspect-[3/4] size-full object-cover"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 pt-8",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("figure", {
								className: "overflow-hidden rounded-xl",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: "/images/about-image-2.webp",
									alt: "Interior window treatments",
									className: "aspect-[4/3] size-full object-cover"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figure", {
								className: "overflow-hidden rounded-xl",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: "/images/about-image-3.webp",
									alt: "Finished home opening",
									className: "aspect-[4/3] size-full object-cover"
								})
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute -bottom-5 left-6 rounded-xl bg-accent px-5 py-4 text-ink shadow-soft",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-display text-3xl font-medium leading-none",
							children: [SITE.years, "+"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs font-semibold uppercase tracking-[0.14em]",
							children: "Years of experience"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
						eyebrow: "About us",
						title: "Premium openings designed for beautiful, protected spaces",
						body: `At ${SITE.name}, we bring together quality craftsmanship and modern design for homes and offices in Hyderabad. From uPVC doors and windows to invisible grills, aluminium partitions, blinds, and ceiling hangers — every product is built for durability, smooth operation, and everyday comfort.`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-xl text-base leading-relaxed text-muted",
						children: "Our mission is simple — stylish protection and better living, with honest pricing and professional installation."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "brand",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/about",
								children: ["Know more about us", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
							})
						})
					})
				] })]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-cream py-16 md:py-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-site",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					eyebrow: "Our products",
					title: "Openings that redefine home comfort",
					body: "Made-to-measure uPVC, aluminium, safety, and finishing systems — without mosquito-mesh products."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3",
					children: PRODUCTS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product: p }, p.slug))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "py-16 md:py-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-site grid items-center gap-12 lg:grid-cols-[1.05fr_0.95fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					eyebrow: "How it works",
					title: "Simple, hassle-free process from start to finish"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-10 space-y-6",
					children: PROCESS_STEPS.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-3xl font-medium text-accent",
							children: step.n
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-base font-semibold text-ink",
							children: step.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm leading-relaxed text-muted",
							children: step.body
						})] })]
					}, step.n))
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figure", {
					className: "overflow-hidden rounded-2xl",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/images/how-it-work-image-1.webp",
						alt: "Measuring a window for custom fabrication",
						className: "aspect-[4/5] size-full object-cover md:aspect-[4/4.4]"
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-cream py-16 md:py-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-site",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					eyebrow: "Features & benefits",
					title: "Designed for comfort, built for safety"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3",
					children: FEATURES.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-xl border border-line bg-surface p-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, { className: "size-6 text-accent" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-4 text-lg font-semibold text-brand",
								children: f.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-muted",
								children: f.body
							})
						]
					}, f.title))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative isolate overflow-hidden bg-ink-soft py-16 md:py-24",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/images/why-choose-bg.webp",
					alt: "",
					className: "absolute inset-0 size-full object-cover opacity-25"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-overlay/70" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "container-site relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
						invert: true,
						eyebrow: "Why choose us",
						title: "Quality you can trust. Service you can rely on."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3",
						children: WHY_US.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "rounded-xl border border-paper/10 bg-paper/5 p-6 backdrop-blur-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-6 text-accent" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-4 text-lg font-semibold text-paper",
									children: item.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-paper/70",
									children: item.body
								})
							]
						}, item.title))
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "py-16 md:py-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-site overflow-hidden rounded-2xl bg-brand px-6 py-12 text-paper md:flex md:items-center md:justify-between md:px-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold uppercase tracking-[0.2em] text-accent",
							children: "Free site visit"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "mt-3 font-display text-3xl font-medium text-paper md:text-4xl",
							children: [
								"Ready for a quote in ",
								SITE.city,
								"?"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-sm leading-relaxed text-paper/80",
							children: [
								"Call ",
								SITE.phoneDisplay,
								" or send a message — we measure, demo, and install across Quthbullapur and surrounding Hyderabad."
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex flex-wrap gap-3 md:mt-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "light",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/contact",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarCheck, {}), "Book a free visit"]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						className: "border-paper/30 bg-transparent text-paper hover:border-paper hover:bg-paper/10 hover:text-paper",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: `tel:${SITE.phone}`,
							children: ["Call ", SITE.phoneDisplay]
						})
					})]
				})]
			})
		})
	] });
}
//#endregion
export { Home as component };
