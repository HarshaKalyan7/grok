//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CY6sEXnL.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/contact",
			"/products/$slug",
			"/products/"
		],
		preloads: ["/assets/index-BspOLoYF.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BspOLoYF.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-C0GTbHTF.js",
			"/assets/product-card-CokemRZB.js",
			"/assets/section-heading-CkUXO-P9.js"
		]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-B9Vqbnis.js",
			"/assets/page-header-mA8QP3wK.js",
			"/assets/section-heading-CkUXO-P9.js"
		]
	},
	"/contact": {
		filePath: "/workspace/src/routes/contact.tsx",
		children: void 0,
		preloads: ["/assets/contact-aUD6ZfIc.js", "/assets/page-header-mA8QP3wK.js"]
	},
	"/products/$slug": {
		filePath: "/workspace/src/routes/products/$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/_slug-Bqc4D3S2.js",
			"/assets/product-card-CokemRZB.js",
			"/assets/page-header-mA8QP3wK.js"
		]
	},
	"/products/": {
		filePath: "/workspace/src/routes/products/index.tsx",
		children: void 0,
		preloads: [
			"/assets/products-DndQ8PTD.js",
			"/assets/product-card-CokemRZB.js",
			"/assets/page-header-mA8QP3wK.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
