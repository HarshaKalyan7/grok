export const SITE = {
  name: "Custom UPVC Screens",
  shortName: "Custom UPVC",
  tagline: "Premium uPVC doors, windows & home solutions in Hyderabad",
  phone: "+917660047005",
  phoneDisplay: "+91 76600 47005",
  email: "customscreens11@gmail.com",
  address:
    "Plot No. 2/A, Opp. Siemens CIE, Gandhi Nagar Road, Quthbullapur, Hyderabad, Telangana, India.",
  addressShort: "Quthbullapur, Hyderabad, Telangana",
  whatsapp: "917660047005",
  maps: "https://maps.app.goo.gl/RTP9akNqryqf3yY86",
  mapsEmbed:
    "https://maps.google.com/maps?q=Plot%20No.%202/A%2C%20Opp.%20Siemens%20CIE%2C%20Gandhi%20Nagar%20Road%2C%20Quthbullapur%2C%20Hyderabad&t=&z=15&ie=UTF8&iwloc=&output=embed",
  years: 25,
  city: "Hyderabad",
} as const;

export const AREAS = [
  "Quthbullapur",
  "Kukatpally",
  "Suchitra",
  "Jeedimetla",
  "Balanagar",
  "Bachupally",
  "Kompally",
  "Miyapur",
  "Pragathi Nagar",
  "All of Hyderabad",
] as const;

export function whatsappUrl(text?: string) {
  const message =
    text ??
    `Hi, ${SITE.name} — I'm interested in a free quote for the products you offer.`;
  return `https://api.whatsapp.com/send?phone=+${SITE.whatsapp}&text=${encodeURIComponent(message)}`;
}

export function telUrl() {
  return `tel:${SITE.phone}`;
}

export function mailtoUrl() {
  return `mailto:${SITE.email}`;
}
