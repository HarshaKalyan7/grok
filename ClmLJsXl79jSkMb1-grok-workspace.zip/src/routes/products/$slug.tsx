import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/site/page-header";
import { ProductCard } from "@/components/site/product-card";
import {
  BLIND_PRICES,
  BLIND_TYPES,
  getProduct,
  PRODUCTS,
} from "@/lib/products";
import { SITE, telUrl } from "@/lib/site";

export const Route = createFileRoute("/products/$slug")({
  component: ProductPage,
  head: ({ params }) => {
    const product = getProduct(params.slug);
    return {
      meta: [
        {
          title: product
            ? `${product.name} in Hyderabad | ${SITE.name}`
            : SITE.name,
        },
        {
          name: "description",
          content: product?.summary ?? SITE.tagline,
        },
      ],
    };
  },
});

function ProductPage() {
  const { slug } = Route.useParams();
  const product = getProduct(slug);
  if (!product) throw notFound();

  const others = PRODUCTS.filter((p) => p.slug !== product.slug);

  return (
    <>
      <PageHeader title={product.name} crumb={product.shortName} />
      <section className="py-16 md:py-24">
        <div className="container-site grid items-start gap-10 lg:grid-cols-[1.05fr_0.95fr]">
          <div>
            <div className="overflow-hidden rounded-2xl border border-line bg-cream">
              <img
                src={product.image}
                alt={product.name}
                className="aspect-[5/4] w-full object-cover"
              />
            </div>
            {product.gallery.length > 1 ? (
              <div className="mt-4 grid grid-cols-4 gap-3">
                {product.gallery.map((src) => (
                  <figure
                    key={src}
                    className="overflow-hidden rounded-md border border-line"
                  >
                    <img
                      src={src}
                      alt=""
                      className="aspect-square size-full object-cover"
                    />
                  </figure>
                ))}
              </div>
            ) : null}
          </div>

          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent">
              {product.eyebrow}
            </p>
            <h2 className="mt-3 font-display text-3xl font-medium text-brand md:text-4xl">
              {product.name}
            </h2>
            <p className="mt-4 text-base leading-relaxed text-muted">
              {product.description}
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild>
                <Link to="/contact">Get a free quote today</Link>
              </Button>
              <Button asChild variant="outline">
                <a href={telUrl()}>Call {SITE.phoneDisplay}</a>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-cream py-16 md:py-24">
        <div className="container-site grid gap-12 lg:grid-cols-2">
          <div>
            <h3 className="font-display text-3xl font-medium text-brand">
              Key features
            </h3>
            <ul className="mt-6 space-y-3">
              {product.features.map((f) => (
                <li key={f} className="flex gap-3 text-sm text-ink">
                  <Check className="mt-0.5 size-4 shrink-0 text-accent" />
                  {f}
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="font-display text-3xl font-medium text-brand">
              Benefits
            </h3>
            <ul className="mt-6 space-y-5">
              {product.benefits.map((b) => (
                <li key={b.title}>
                  <h4 className="text-base font-semibold text-ink">{b.title}</h4>
                  <p className="mt-1 text-sm leading-relaxed text-muted">
                    {b.body}
                  </p>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24">
        <div className="container-site">
          <h3 className="font-display text-3xl font-medium text-brand">
            Where can they be used?
          </h3>
          <ul className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {product.uses.map((u) => (
              <li
                key={u}
                className="rounded-lg border border-line bg-surface px-4 py-3 text-sm font-medium text-ink"
              >
                {u}
              </li>
            ))}
          </ul>

          {product.slug === "window-blinds" ? (
            <div className="mt-14 grid gap-10 lg:grid-cols-2">
              <div>
                <h3 className="font-display text-3xl font-medium text-brand">
                  Types of blinds
                </h3>
                <ul className="mt-5 space-y-2">
                  {BLIND_TYPES.map((t) => (
                    <li key={t} className="flex gap-3 text-sm text-ink">
                      <Check className="mt-0.5 size-4 text-accent" />
                      {t}
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h3 className="font-display text-3xl font-medium text-brand">
                  Indicative price range
                </h3>
                <p className="mt-2 text-sm text-muted">
                  Final cost depends on type, window size, and fabric. Ask for a
                  free quotation.
                </p>
                <ul className="mt-5 divide-y divide-line overflow-hidden rounded-xl border border-line bg-surface">
                  {BLIND_PRICES.map((row) => (
                    <li
                      key={row.type}
                      className="flex items-center justify-between px-4 py-3 text-sm"
                    >
                      <span className="font-medium text-ink">{row.type}</span>
                      <span className="text-muted">{row.range}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ) : null}

          <div className="mt-14 overflow-hidden rounded-2xl bg-brand px-6 py-10 text-paper md:flex md:items-center md:justify-between md:px-10">
            <div>
              <h3 className="font-display text-3xl font-medium text-paper">
                {product.cta}
              </h3>
              <p className="mt-2 text-sm text-paper/75">
                Book a free visit in {SITE.city}. We’ll measure, show samples,
                and quote clearly.
              </p>
            </div>
            <Button asChild variant="light" className="mt-6 md:mt-0">
              <Link to="/contact">Get a free quote today</Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="bg-cream py-16 md:py-24">
        <div className="container-site">
          <h3 className="font-display text-3xl font-medium text-brand">
            Other products
          </h3>
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {others.map((p) => (
              <ProductCard key={p.slug} product={p} />
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
