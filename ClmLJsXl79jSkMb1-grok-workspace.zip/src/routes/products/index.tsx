import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/site/page-header";
import { ProductCard } from "@/components/site/product-card";
import { PRODUCTS } from "@/lib/products";
import { SITE } from "@/lib/site";

export const Route = createFileRoute("/products/")({
  component: ProductsIndex,
  head: () => ({
    meta: [
      { title: `Our Products | ${SITE.name}` },
      {
        name: "description",
        content:
          "uPVC doors and windows, aluminium partitions, invisible grills, window blinds, and ceiling cloth hangers in Hyderabad.",
      },
    ],
  }),
});

function ProductsIndex() {
  return (
    <>
      <PageHeader title="Our products" />
      <section className="py-16 md:py-24">
        <div className="container-site">
          <p className="max-w-2xl text-base leading-relaxed text-muted">
            Custom-fitted uPVC doors and windows, aluminium partitions, invisible
            grills, window blinds, and ceiling cloth hangers — fabricated and
            installed in Hyderabad. Mosquito-mesh systems are not part of this
            range.
          </p>
          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {PRODUCTS.map((p) => (
              <ProductCard key={p.slug} product={p} />
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
