import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowRight,
  BadgeCheck,
  CalendarCheck,
  ShieldCheck,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { HeroSlider } from "@/components/site/hero-slider";
import { ProductCard } from "@/components/site/product-card";
import { SectionHeading } from "@/components/site/section-heading";
import {
  FEATURES,
  PROCESS_STEPS,
  PRODUCTS,
  WHY_US,
} from "@/lib/products";
import { SITE } from "@/lib/site";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <>
      <HeroSlider />

      <section className="py-16 md:py-24">
        <div className="container-site grid items-center gap-12 lg:grid-cols-2">
          <div className="relative mb-8 pb-6">
            <div className="grid grid-cols-2 gap-4">
              <figure className="overflow-hidden rounded-xl">
                <img
                  src="/images/about-image-1.webp"
                  alt="uPVC window installation"
                  className="aspect-[3/4] size-full object-cover"
                />
              </figure>
              <div className="grid gap-4 pt-8">
                <figure className="overflow-hidden rounded-xl">
                  <img
                    src="/images/about-image-2.webp"
                    alt="Interior window treatments"
                    className="aspect-[4/3] size-full object-cover"
                  />
                </figure>
                <figure className="overflow-hidden rounded-xl">
                  <img
                    src="/images/about-image-3.webp"
                    alt="Finished home opening"
                    className="aspect-[4/3] size-full object-cover"
                  />
                </figure>
              </div>
            </div>
            <div className="absolute -bottom-5 left-6 rounded-xl bg-accent px-5 py-4 text-ink shadow-soft">
              <p className="font-display text-3xl font-medium leading-none">
                {SITE.years}+
              </p>
              <p className="mt-1 text-xs font-semibold uppercase tracking-[0.14em]">
                Years of experience
              </p>
            </div>
          </div>

          <div>
            <SectionHeading
              eyebrow="About us"
              title="Premium openings designed for beautiful, protected spaces"
              body={`At ${SITE.name}, we bring together quality craftsmanship and modern design for homes and offices in Hyderabad. From uPVC doors and windows to invisible grills, aluminium partitions, blinds, and ceiling hangers — every product is built for durability, smooth operation, and everyday comfort.`}
            />
            <p className="mt-4 max-w-xl text-base leading-relaxed text-muted">
              Our mission is simple — stylish protection and better living, with
              honest pricing and professional installation.
            </p>
            <div className="mt-8">
              <Button asChild variant="brand">
                <Link to="/about">
                  Know more about us
                  <ArrowRight />
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-cream py-16 md:py-24">
        <div className="container-site">
          <SectionHeading
            eyebrow="Our products"
            title="Openings that redefine home comfort"
            body="Made-to-measure uPVC, aluminium, safety, and finishing systems — without mosquito-mesh products."
          />
          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {PRODUCTS.map((p) => (
              <ProductCard key={p.slug} product={p} />
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24">
        <div className="container-site grid items-center gap-12 lg:grid-cols-[1.05fr_0.95fr]">
          <div>
            <SectionHeading
              eyebrow="How it works"
              title="Simple, hassle-free process from start to finish"
            />
            <ol className="mt-10 space-y-6">
              {PROCESS_STEPS.map((step) => (
                <li key={step.n} className="flex gap-4">
                  <span className="font-display text-3xl font-medium text-accent">
                    {step.n}
                  </span>
                  <div>
                    <h3 className="text-base font-semibold text-ink">
                      {step.title}
                    </h3>
                    <p className="mt-1 text-sm leading-relaxed text-muted">
                      {step.body}
                    </p>
                  </div>
                </li>
              ))}
            </ol>
          </div>
          <figure className="overflow-hidden rounded-2xl">
            <img
              src="/images/how-it-work-image-1.webp"
              alt="Measuring a window for custom fabrication"
              className="aspect-[4/5] size-full object-cover md:aspect-[4/4.4]"
            />
          </figure>
        </div>
      </section>

      <section className="bg-cream py-16 md:py-24">
        <div className="container-site">
          <SectionHeading
            eyebrow="Features & benefits"
            title="Designed for comfort, built for safety"
          />
          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {FEATURES.map((f) => (
              <article
                key={f.title}
                className="rounded-xl border border-line bg-surface p-6"
              >
                <BadgeCheck className="size-6 text-accent" />
                <h3 className="mt-4 text-lg font-semibold text-brand">
                  {f.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-muted">
                  {f.body}
                </p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="relative isolate overflow-hidden bg-ink-soft py-16 md:py-24">
        <img
          src="/images/why-choose-bg.webp"
          alt=""
          className="absolute inset-0 size-full object-cover opacity-25"
        />
        <div className="absolute inset-0 bg-overlay/70" />
        <div className="container-site relative">
          <SectionHeading
            invert
            eyebrow="Why choose us"
            title="Quality you can trust. Service you can rely on."
          />
          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {WHY_US.map((item) => (
              <article
                key={item.title}
                className="rounded-xl border border-paper/10 bg-paper/5 p-6 backdrop-blur-sm"
              >
                <ShieldCheck className="size-6 text-accent" />
                <h3 className="mt-4 text-lg font-semibold text-paper">
                  {item.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-paper/70">
                  {item.body}
                </p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24">
        <div className="container-site overflow-hidden rounded-2xl bg-brand px-6 py-12 text-paper md:flex md:items-center md:justify-between md:px-12">
          <div className="max-w-xl">
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent">
              Free site visit
            </p>
            <h2 className="mt-3 font-display text-3xl font-medium text-paper md:text-4xl">
              Ready for a quote in {SITE.city}?
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-paper/80">
              Call {SITE.phoneDisplay} or send a message — we measure, demo, and
              install across Quthbullapur and surrounding Hyderabad.
            </p>
          </div>
          <div className="mt-8 flex flex-wrap gap-3 md:mt-0">
            <Button asChild variant="light">
              <Link to="/contact">
                <CalendarCheck />
                Book a free visit
              </Link>
            </Button>
            <Button asChild variant="outline" className="border-paper/30 bg-transparent text-paper hover:border-paper hover:bg-paper/10 hover:text-paper">
              <a href={`tel:${SITE.phone}`}>Call {SITE.phoneDisplay}</a>
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}
