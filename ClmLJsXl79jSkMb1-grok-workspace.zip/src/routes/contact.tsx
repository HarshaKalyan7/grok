import { createFileRoute } from "@tanstack/react-router";
import { Mail, MapPin, Phone } from "lucide-react";
import { PageHeader } from "@/components/site/page-header";
import { QuoteForm } from "@/components/site/quote-form";
import { AREAS, SITE, mailtoUrl, telUrl } from "@/lib/site";

export const Route = createFileRoute("/contact")({
  component: ContactPage,
  head: () => ({
    meta: [
      { title: `Contact | ${SITE.name}` },
      {
        name: "description",
        content: `Contact ${SITE.name} in Quthbullapur, Hyderabad. Call ${SITE.phoneDisplay} or WhatsApp for a free site visit and quote.`,
      },
    ],
  }),
});

function ContactPage() {
  return (
    <>
      <PageHeader title="Contact us" />
      <section className="py-16 md:py-24">
        <div className="container-site grid gap-10 lg:grid-cols-[0.9fr_1.1fr]">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent">
              Visit or call
            </p>
            <h2 className="mt-3 font-display text-3xl font-medium text-brand md:text-4xl">
              Let’s plan your openings
            </h2>
            <p className="mt-4 text-base leading-relaxed text-muted">
              Free site visit, measurement, and quote across Hyderabad. Same
              workshop, same phone number — now focused on uPVC, partitions,
              invisible grills, blinds, and hangers.
            </p>

            <ul className="mt-8 space-y-5">
              <li className="flex gap-4">
                <span className="inline-flex size-11 shrink-0 items-center justify-center rounded-md bg-cream text-brand">
                  <MapPin className="size-5" />
                </span>
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.16em] text-muted">
                    Our location
                  </p>
                  <p className="mt-1 text-sm leading-relaxed text-ink">
                    {SITE.address}
                  </p>
                  <a
                    href={SITE.maps}
                    target="_blank"
                    rel="noreferrer"
                    className="mt-1 inline-block text-sm font-semibold text-brand hover:text-accent"
                  >
                    Open in Google Maps
                  </a>
                </div>
              </li>
              <li className="flex gap-4">
                <span className="inline-flex size-11 shrink-0 items-center justify-center rounded-md bg-cream text-brand">
                  <Phone className="size-5" />
                </span>
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.16em] text-muted">
                    Call us
                  </p>
                  <a
                    href={telUrl()}
                    className="mt-1 block text-sm font-semibold text-ink hover:text-brand"
                  >
                    {SITE.phoneDisplay}
                  </a>
                </div>
              </li>
              <li className="flex gap-4">
                <span className="inline-flex size-11 shrink-0 items-center justify-center rounded-md bg-cream text-brand">
                  <Mail className="size-5" />
                </span>
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.16em] text-muted">
                    Email us
                  </p>
                  <a
                    href={mailtoUrl()}
                    className="mt-1 block text-sm font-semibold text-ink hover:text-brand"
                  >
                    {SITE.email}
                  </a>
                </div>
              </li>
            </ul>

            <div className="mt-10">
              <p className="text-xs font-semibold uppercase tracking-[0.16em] text-muted">
                Service areas
              </p>
              <ul className="mt-3 flex flex-wrap gap-2">
                {AREAS.map((area) => (
                  <li
                    key={area}
                    className="rounded-pill border border-line bg-surface px-3 py-1.5 text-xs font-medium text-ink"
                  >
                    {area}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <QuoteForm />
        </div>
      </section>

      <section className="pb-16 md:pb-24">
        <div className="container-site overflow-hidden rounded-2xl border border-line">
          <iframe
            title="Custom UPVC Screens location in Quthbullapur, Hyderabad"
            src={SITE.mapsEmbed}
            className="h-80 w-full border-0 md:h-[420px]"
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
      </section>
    </>
  );
}
