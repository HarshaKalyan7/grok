import { createFileRoute, Link } from "@tanstack/react-router";
import { Compass, Eye, HeartHandshake } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/site/page-header";
import { SectionHeading } from "@/components/site/section-heading";
import { WHY_US } from "@/lib/products";
import { SITE } from "@/lib/site";

export const Route = createFileRoute("/about")({
  component: AboutPage,
  head: () => ({
    meta: [
      {
        title: `About Us | ${SITE.name}`,
      },
      {
        name: "description",
        content: `About ${SITE.name} — ${SITE.years}+ years of uPVC doors, windows, partitions, invisible grills, and blinds in Hyderabad.`,
      },
    ],
  }),
});

function AboutPage() {
  return (
    <>
      <PageHeader title="About us" />
      <section className="py-16 md:py-24">
        <div className="container-site grid items-start gap-12 lg:grid-cols-2">
          <div>
            <SectionHeading
              eyebrow="About us"
              title="Premium openings designed for beautiful, protected spaces"
              body={`At ${SITE.name}, we bring together quality craftsmanship and modern design to create long-lasting solutions for homes and offices. From uPVC doors and windows to invisible grills, aluminium partitions, blinds, and ceiling hangers, every product is built for durability, smooth operation, and everyday comfort.`}
            />
            <p className="mt-4 text-base leading-relaxed text-muted">
              We are a dedicated team of professionals committed to high-quality
              work that meets your needs and exceeds expectations. With {SITE.years}+
              years of experience in Hyderabad, we combine expertise, careful
              installation, and honest service.
            </p>
            <div className="mt-8">
              <Button asChild>
                <Link to="/contact">Get a free quote</Link>
              </Button>
            </div>
          </div>
          <figure className="overflow-hidden rounded-2xl">
            <img
              src="/images/our-approach-image.webp"
              alt="Craftsman installing a custom window system"
              className="aspect-[5/4] size-full object-cover"
            />
          </figure>
        </div>
      </section>

      <section className="bg-cream py-16 md:py-24">
        <div className="container-site grid gap-6 md:grid-cols-3">
          <article className="rounded-xl border border-line bg-surface p-7">
            <Compass className="size-7 text-accent" />
            <h3 className="mt-5 font-display text-2xl font-medium text-brand">
              Our mission
            </h3>
            <p className="mt-3 text-sm leading-relaxed text-muted">
              To provide stylish protection that enhances the way you live,
              while ensuring reliability, craftsmanship, and customer
              satisfaction in every solution we offer.
            </p>
          </article>
          <article className="rounded-xl border border-line bg-surface p-7">
            <Eye className="size-7 text-accent" />
            <h3 className="mt-5 font-display text-2xl font-medium text-brand">
              Our vision
            </h3>
            <p className="mt-3 text-sm leading-relaxed text-muted">
              To be the trusted name in custom uPVC and home opening solutions
              in Hyderabad — setting the standard for quality, finish, and
              service.
            </p>
          </article>
          <article className="rounded-xl border border-line bg-surface p-7">
            <HeartHandshake className="size-7 text-accent" />
            <h3 className="mt-5 font-display text-2xl font-medium text-brand">
              Our values
            </h3>
            <p className="mt-3 text-sm leading-relaxed text-muted">
              Honesty and transparency in all we do. Every product and
              installation should meet a high standard — measured twice, fitted
              once, supported after.
            </p>
          </article>
        </div>
      </section>

      <section className="py-16 md:py-24">
        <div className="container-site">
          <SectionHeading
            title="Quality you can trust. Service you can rely on."
            body="The same workshop discipline, on-site care, and after-sales support our Hyderabad customers already know."
          />
          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {WHY_US.map((item) => (
              <article
                key={item.title}
                className="rounded-xl border border-line bg-surface p-6"
              >
                <h3 className="text-lg font-semibold text-brand">{item.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted">
                  {item.body}
                </p>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
