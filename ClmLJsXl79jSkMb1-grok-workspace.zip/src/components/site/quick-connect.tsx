import { Phone } from "lucide-react";
import { SITE, telUrl, whatsappUrl } from "@/lib/site";

export function QuickConnect() {
  return (
    <>
      <aside className="fixed right-0 top-1/2 z-40 hidden -translate-y-1/2 flex-col overflow-hidden rounded-l-lg bg-brand shadow-soft md:flex">
        <p className="bg-ink px-3 py-2 text-center text-[11px] font-semibold uppercase tracking-[0.16em] text-paper">
          Quick connect
        </p>
        <a
          href={whatsappUrl()}
          target="_blank"
          rel="noreferrer"
          className="flex items-center gap-2 px-3 py-3 text-sm font-semibold text-paper hover:bg-brand-deep"
        >
          <img src="/images/whatsapp.webp" alt="" className="size-7" />
          WhatsApp
        </a>
        <a
          href={telUrl()}
          className="flex items-center gap-2 border-t border-paper/15 px-3 py-3 text-sm font-semibold text-paper hover:bg-brand-deep"
        >
          <img src="/images/call.webp" alt="" className="size-7" />
          Call
        </a>
      </aside>

      <div className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-paper md:hidden">
        <div className="grid grid-cols-2">
          <a
            href={telUrl()}
            className="flex h-14 items-center justify-center gap-2 bg-brand text-sm font-semibold text-paper"
          >
            <Phone className="size-4" />
            Call now
          </a>
          <a
            href={whatsappUrl()}
            target="_blank"
            rel="noreferrer"
            className="flex h-14 items-center justify-center gap-2 bg-chat text-sm font-semibold text-paper"
          >
            WhatsApp
          </a>
        </div>
      </div>
      <p className="sr-only">{SITE.phoneDisplay}</p>
    </>
  );
}
