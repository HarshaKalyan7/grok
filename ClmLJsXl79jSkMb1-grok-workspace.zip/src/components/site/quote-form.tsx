import { useState, type FormEvent } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { PRODUCTS } from "@/lib/products";
import { SITE, whatsappUrl } from "@/lib/site";
import { cn } from "@/lib/utils";

export function QuoteForm({ className }: { className?: string }) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [product, setProduct] = useState("");
  const [message, setMessage] = useState("");

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) {
      toast.error("Please add your name and phone number.");
      return;
    }
    const lines = [
      `Hi, ${SITE.name} — I'd like a free quote.`,
      `Name: ${name.trim()}`,
      `Phone: ${phone.trim()}`,
      email.trim() ? `Email: ${email.trim()}` : null,
      product ? `Product: ${product}` : null,
      message.trim() ? `Message: ${message.trim()}` : null,
    ].filter(Boolean);
    window.open(whatsappUrl(lines.join("\n")), "_blank", "noopener,noreferrer");
    toast.success("Opening WhatsApp with your enquiry.");
  }

  return (
    <form
      onSubmit={onSubmit}
      className={cn(
        "rounded-2xl border border-line bg-surface p-6 shadow-soft md:p-8",
        className,
      )}
    >
      <h3 className="font-display text-2xl font-medium text-brand">
        Reach out for a free consultation
      </h3>
      <p className="mt-2 text-sm text-muted">
        Share a few details and we’ll get back with a site visit and quote.
      </p>
      <div className="mt-6 grid gap-4">
        <div className="grid gap-2">
          <Label htmlFor="quote-name">Name</Label>
          <Input
            id="quote-name"
            name="name"
            autoComplete="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Your name"
            required
          />
        </div>
        <div className="grid gap-2 sm:grid-cols-2 sm:gap-4">
          <div className="grid gap-2">
            <Label htmlFor="quote-phone">Phone</Label>
            <Input
              id="quote-phone"
              name="phone"
              type="tel"
              autoComplete="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="Mobile number"
              required
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="quote-email">Email</Label>
            <Input
              id="quote-email"
              name="email"
              type="email"
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Optional"
            />
          </div>
        </div>
        <div className="grid gap-2">
          <Label htmlFor="quote-product">Product</Label>
          <select
            id="quote-product"
            name="product"
            value={product}
            onChange={(e) => setProduct(e.target.value)}
            className="flex h-11 w-full rounded-md border border-line bg-surface px-3.5 text-sm text-ink-soft focus-visible:border-brand focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40"
          >
            <option value="">Select a product</option>
            {PRODUCTS.map((p) => (
              <option key={p.slug} value={p.name}>
                {p.name}
              </option>
            ))}
            <option value="Not sure yet">Not sure yet</option>
          </select>
        </div>
        <div className="grid gap-2">
          <Label htmlFor="quote-message">Message</Label>
          <Textarea
            id="quote-message"
            name="message"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Tell us about your doors, windows, or balcony…"
          />
        </div>
        <Button type="submit" size="lg" className="mt-2 w-full sm:w-auto">
          Send on WhatsApp
        </Button>
      </div>
    </form>
  );
}
