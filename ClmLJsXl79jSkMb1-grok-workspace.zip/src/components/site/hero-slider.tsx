import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const SLIDES = [
  {
    image: "/images/sliders/slider-1.webp",
    eyebrow: "Elegant protection for every home",
    title: "Premium uPVC for modern living",
    body: "Upgrade your windows and doors with durable, stylish uPVC systems made to fit.",
    cta: "Explore products",
    to: "/products",
  },
  {
    image: "/images/sliders/slider-2.webp",
    eyebrow: "Comfort, light, and finish",
    title: "Blinds and openings built for daily use",
    body: "Custom-fitted blinds, partitions, and uPVC that look considered — and work every day.",
    cta: "View solutions",
    to: "/contact",
  },
  {
    image: "/images/sliders/slider-3.webp",
    eyebrow: "Smart safety for modern spaces",
    title: "Invisible grills. Open views.",
    body: "Protect balconies and windows without the look of heavy bars.",
    cta: "Get a free quote",
    to: "/contact",
  },
] as const;

export function HeroSlider() {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const id = window.setInterval(() => {
      setIndex((i) => (i + 1) % SLIDES.length);
    }, 6500);
    return () => window.clearInterval(id);
  }, []);

  return (
    <section className="relative isolate h-[calc(100dvh-4rem)] min-h-[560px] max-h-[820px] overflow-hidden bg-overlay md:h-[calc(100dvh-6.5rem)]">
      {SLIDES.map((slide, i) => (
        <div
          key={slide.title}
          className={cn(
            "absolute inset-0 transition-opacity duration-700 ease-out",
            i === index ? "opacity-100" : "opacity-0",
          )}
          aria-hidden={i !== index}
        >
          <img
            src={slide.image}
            alt=""
            className="size-full object-cover"
          />
          <div className="absolute inset-0 bg-[linear-gradient(90deg,rgb(20_12_4/0.78)_0%,rgb(20_12_4/0.45)_55%,rgb(20_12_4/0.18)_100%)]" />
        </div>
      ))}

      <div className="container-site relative flex h-full items-end pb-24 md:items-center md:pb-16">
        <div className="max-w-xl">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-accent">
            {SLIDES[index].eyebrow}
          </p>
          <h1 className="mt-3 font-display text-[2.15rem] font-medium leading-[1.12] tracking-tight text-paper sm:text-4xl md:text-6xl md:leading-[1.08]">
            {SLIDES[index].title}
          </h1>
          <p className="mt-4 max-w-md text-sm leading-relaxed text-paper/80 md:mt-5 md:text-lg">
            {SLIDES[index].body}
          </p>
          <div className="mt-6 md:mt-8">
            <Button asChild variant="light" size="lg">
              <Link to={SLIDES[index].to}>{SLIDES[index].cta}</Link>
            </Button>
          </div>
        </div>
      </div>

      <div className="absolute bottom-20 left-1/2 z-10 flex -translate-x-1/2 gap-2 md:bottom-8">
        {SLIDES.map((s, i) => (
          <button
            key={s.title}
            type="button"
            aria-label={`Show slide ${i + 1}`}
            className={cn(
              "h-2 rounded-pill transition-[width,background-color] duration-300",
              i === index ? "w-8 bg-accent" : "w-2 bg-paper/45 hover:bg-paper/80",
            )}
            onClick={() => setIndex(i)}
          />
        ))}
      </div>
    </section>
  );
}
