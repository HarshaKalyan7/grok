import type { ReactNode } from "react";
import { Toaster } from "sonner";
import { Footer } from "@/components/site/footer";
import { Header } from "@/components/site/header";
import { QuickConnect } from "@/components/site/quick-connect";

export function SiteShell({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-dvh flex-col bg-paper text-ink-soft">
      <Header />
      <main className="flex-1 pb-14 md:pb-0">{children}</main>
      <Footer />
      <QuickConnect />
      <Toaster
        position="top-center"
        toastOptions={{
          className: "font-sans",
        }}
      />
    </div>
  );
}
