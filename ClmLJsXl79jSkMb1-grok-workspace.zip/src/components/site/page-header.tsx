import { Link } from "@tanstack/react-router";
import { ChevronRight } from "lucide-react";

export function PageHeader({
  title,
  crumb,
}: {
  title: string;
  crumb?: string;
}) {
  return (
    <section className="relative isolate overflow-hidden bg-ink-soft py-16 md:py-20">
      <img
        src="/images/page-header-bg.webp"
        alt=""
        className="absolute inset-0 size-full object-cover opacity-40"
      />
      <div className="absolute inset-0 bg-linear-to-r from-overlay/85 via-overlay/70 to-overlay/40" />
      <div className="container-site relative">
        <h1 className="font-display text-4xl font-medium tracking-tight text-paper md:text-5xl">
          {title}
        </h1>
        <nav
          className="mt-4 flex flex-wrap items-center gap-2 text-sm text-paper/75"
          aria-label="Breadcrumb"
        >
          <Link to="/" className="hover:text-accent">
            Home
          </Link>
          <ChevronRight className="size-3.5" />
          <span className="text-accent">{crumb ?? title}</span>
        </nav>
      </div>
    </section>
  );
}
