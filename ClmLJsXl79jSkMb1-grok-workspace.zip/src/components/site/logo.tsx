import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/utils";
import { SITE } from "@/lib/site";

export function Logo({
  className,
  inverted = false,
}: {
  className?: string;
  inverted?: boolean;
}) {
  return (
    <Link
      to="/"
      className={cn("group flex items-center gap-3 no-underline", className)}
      aria-label={SITE.name}
    >
      <svg
        viewBox="0 0 44 44"
        className="size-11 shrink-0"
        aria-hidden="true"
      >
        <rect width="44" height="44" rx="10" fill={inverted ? "#d2a03c" : "#87510b"} />
        <path
          fill={inverted ? "#442d0f" : "#d2a03c"}
          d="M22 7.2l11.2 4.4v9.7c0 7-4.7 13.2-11.2 15.4C15.5 34.5 10.8 28.3 10.8 21.3V11.6L22 7.2z"
        />
        <path
          fill={inverted ? "#f7f3ec" : "#442d0f"}
          d="M22 12.4l-6.4 2.5v6.4c0 4.4 2.9 8.4 6.4 9.8 3.5-1.4 6.4-5.4 6.4-9.8v-6.4L22 12.4z"
        />
        <path
          fill={inverted ? "#87510b" : "#f7f3ec"}
          d="M22 17.8l3.3 4.7h-2.1l.8 3.3L22 23.8l-2 2 .8-3.3h-2.1L22 17.8z"
        />
      </svg>
      <span className="flex min-w-0 flex-col leading-none">
        <span
          className={cn(
            "font-display text-[1.35rem] italic leading-none",
            inverted ? "text-paper" : "text-accent",
          )}
        >
          Custom
        </span>
        <span
          className={cn(
            "mt-0.5 text-[0.68rem] font-semibold tracking-[0.18em]",
            inverted ? "text-paper/85" : "text-brand",
          )}
        >
          UPVC SCREENS
        </span>
      </span>
    </Link>
  );
}
