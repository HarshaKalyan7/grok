import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";

export function NotFound() {
  return (
    <section className="container-site flex min-h-[50vh] flex-col items-center justify-center py-24 text-center">
      <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent">
        404
      </p>
      <h1 className="mt-3 font-display text-4xl font-medium text-brand">
        Page not found
      </h1>
      <p className="mt-3 max-w-md text-sm text-muted">
        That page doesn’t exist. Browse our products or request a free quote.
      </p>
      <div className="mt-8 flex flex-wrap justify-center gap-3">
        <Button asChild>
          <Link to="/">Back home</Link>
        </Button>
        <Button asChild variant="outline">
          <Link to="/products">Our products</Link>
        </Button>
      </div>
    </section>
  );
}
