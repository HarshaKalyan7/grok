import { cn } from "@/lib/utils";

export function SectionHeading({
  eyebrow,
  title,
  body,
  invert = false,
  align = "left",
}: {
  eyebrow?: string;
  title: string;
  body?: string;
  invert?: boolean;
  align?: "left" | "center";
}) {
  return (
    <div
      className={cn(
        "max-w-2xl",
        align === "center" && "mx-auto text-center",
      )}
    >
      {eyebrow ? (
        <p
          className={cn(
            "text-xs font-semibold uppercase tracking-[0.22em]",
            invert ? "text-accent" : "text-accent",
          )}
        >
          {eyebrow}
        </p>
      ) : null}
      <h2
        className={cn(
          "mt-3 font-display text-3xl font-medium leading-tight tracking-tight md:text-4xl lg:text-[2.75rem]",
          invert ? "text-paper" : "text-brand",
        )}
      >
        {title}
      </h2>
      {body ? (
        <p
          className={cn(
            "mt-4 text-base leading-relaxed",
            invert ? "text-paper/75" : "text-muted",
          )}
        >
          {body}
        </p>
      ) : null}
    </div>
  );
}
