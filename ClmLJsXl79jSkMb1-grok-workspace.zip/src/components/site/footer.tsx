import { Link } from "@tanstack/react-router";
import { Mail, MapPin, Phone } from "lucide-react";
import { SITE, mailtoUrl, telUrl } from "@/lib/site";
import { PRODUCTS } from "@/lib/products";
import { Logo } from "@/components/site/logo";

export function Footer() {
  return (
    <footer className="bg-ink-soft text-paper">
      <div className="container-site py-14 md:py-16">
        <div className="flex flex-col gap-8 border-b border-paper/10 pb-10 md:flex-row md:items-end md:justify-between">
          <Logo inverted />
          <p className="max-w-md text-sm leading-relaxed text-paper/70">
            {SITE.years}+ years of craftsmanship in Hyderabad — uPVC doors and
            windows, aluminium partitions, invisible grills, blinds, and ceiling
            hangers. Built to measure. Installed with care.
          </p>
        </div>

        <div className="grid gap-10 pt-10 md:grid-cols-3">
          <div>
            <h3 className="font-display text-2xl font-medium text-paper">
              About us
            </h3>
            <p className="mt-4 text-sm leading-relaxed text-paper/70">
              Custom UPVC Screens brings quality fabrication and modern design
              to homes and offices across Hyderabad. Every product is made for
              durability, smooth operation, and everyday comfort.
            </p>
          </div>

          <div>
            <h3 className="font-display text-2xl font-medium text-paper">
              Our products
            </h3>
            <ul className="mt-4 grid gap-2 text-sm">
              {PRODUCTS.map((p) => (
                <li key={p.slug}>
                  <Link
                    to="/products/$slug"
                    params={{ slug: p.slug }}
                    className="text-paper/75 transition-colors hover:text-accent"
                  >
                    {p.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-display text-2xl font-medium text-paper">
              Contact
            </h3>
            <ul className="mt-4 space-y-3 text-sm text-paper/75">
              <li className="flex gap-3">
                <MapPin className="mt-0.5 size-4 shrink-0 text-accent" />
                {SITE.address}
              </li>
              <li className="flex gap-3">
                <Phone className="mt-0.5 size-4 shrink-0 text-accent" />
                <a href={telUrl()} className="hover:text-accent">
                  {SITE.phoneDisplay}
                </a>
              </li>
              <li className="flex gap-3">
                <Mail className="mt-0.5 size-4 shrink-0 text-accent" />
                <a href={mailtoUrl()} className="hover:text-accent">
                  {SITE.email}
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div className="border-t border-paper/10">
        <div className="container-site flex flex-col gap-2 py-5 text-xs text-paper/55 sm:flex-row sm:justify-between">
          <p>
            © {new Date().getFullYear()} {SITE.name}. All rights reserved.
          </p>
          <p>{SITE.addressShort}</p>
        </div>
      </div>
    </footer>
  );
}
