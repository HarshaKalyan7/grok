import { Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import type { Product } from "@/lib/products";

export function ProductCard({ product }: { product: Product }) {
  return (
    <Link
      to="/products/$slug"
      params={{ slug: product.slug }}
      className="group block overflow-hidden rounded-xl border border-line bg-surface shadow-lift transition-[transform,box-shadow] duration-200 hover:-translate-y-0.5 hover:shadow-soft"
    >
      <div className="relative aspect-[4/3] overflow-hidden bg-cream">
        <img
          src={product.thumb}
          alt={product.name}
          className="size-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
        />
        <span className="absolute right-3 top-3 inline-flex size-9 items-center justify-center rounded-full bg-paper text-brand opacity-0 shadow-lift transition-opacity duration-200 group-hover:opacity-100">
          <ArrowUpRight className="size-4" />
        </span>
      </div>
      <div className="p-5">
        <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-accent">
          {product.eyebrow}
        </p>
        <h3 className="mt-1 font-display text-2xl font-medium text-brand">
          {product.shortName}
        </h3>
        <p className="mt-2 text-sm leading-relaxed text-muted">
          {product.summary}
        </p>
      </div>
    </Link>
  );
}
