import { Link, useRouterState } from "@tanstack/react-router";
import { Menu, Phone, X } from "lucide-react";
import { useEffect, useState } from "react";
import { SITE, telUrl, whatsappUrl } from "@/lib/site";
import { PRODUCTS } from "@/lib/products";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Logo } from "@/components/site/logo";

const NAV = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About Us" },
  { to: "/products", label: "Our Products" },
  { to: "/contact", label: "Contact" },
] as const;

export function Header() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [productsOpen, setProductsOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
    setProductsOpen(false);
  }, [pathname]);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <header className="sticky top-0 z-50">
      <div className="hidden border-b border-ink/10 bg-brand text-paper md:block">
        <div className="container-site flex h-10 items-center justify-between text-[13px]">
          <div className="flex items-center gap-6">
            <a
              href={telUrl()}
              className="inline-flex items-center gap-2 text-paper/90 hover:text-paper"
            >
              <Phone className="size-3.5" />
              {SITE.phoneDisplay}
            </a>
            <a
              href={`mailto:${SITE.email}`}
              className="text-paper/90 hover:text-paper"
            >
              {SITE.email}
            </a>
          </div>
          <p className="text-paper/80">Free site visit across {SITE.city}</p>
        </div>
      </div>

      <div
        className={cn(
          "border-b bg-paper/95 backdrop-blur-md transition-shadow duration-200",
          scrolled ? "border-line shadow-lift" : "border-line/60",
        )}
      >
        <div className="container-site flex h-16 items-center justify-between gap-4 md:h-[4.5rem]">
          <Logo />

          <nav className="hidden items-center gap-1 lg:flex" aria-label="Primary">
            {NAV.map((item) => {
              if (item.to === "/products") {
                return (
                  <div
                    key={item.to}
                    className="relative"
                    onMouseEnter={() => setProductsOpen(true)}
                    onMouseLeave={() => setProductsOpen(false)}
                  >
                    <Link
                      to={item.to}
                      className={cn(
                        "inline-flex h-11 items-center px-3 text-sm font-semibold transition-colors",
                        pathname.startsWith("/products")
                          ? "text-brand"
                          : "text-ink hover:text-brand",
                      )}
                    >
                      {item.label}
                    </Link>
                    <div
                      className={cn(
                        "absolute left-0 top-full w-72 origin-top rounded-xl border border-line bg-surface p-2 shadow-soft transition-[opacity,transform] duration-200",
                        productsOpen
                          ? "pointer-events-auto translate-y-0 opacity-100"
                          : "pointer-events-none -translate-y-1 opacity-0",
                      )}
                    >
                      {PRODUCTS.map((p) => (
                        <Link
                          key={p.slug}
                          to="/products/$slug"
                          params={{ slug: p.slug }}
                          className="block rounded-md px-3 py-2.5 text-sm text-ink hover:bg-cream hover:text-brand"
                        >
                          {p.shortName}
                        </Link>
                      ))}
                    </div>
                  </div>
                );
              }
              const active =
                item.to === "/"
                  ? pathname === "/"
                  : pathname.startsWith(item.to);
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "inline-flex h-11 items-center px-3 text-sm font-semibold transition-colors",
                    active ? "text-brand" : "text-ink hover:text-brand",
                  )}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>

          <div className="flex items-center gap-2">
            <Button asChild size="sm" className="hidden sm:inline-flex">
              <Link to="/contact">Get a free quote</Link>
            </Button>
            <button
              type="button"
              className="inline-flex size-11 items-center justify-center rounded-md text-ink lg:hidden"
              aria-label={open ? "Close menu" : "Open menu"}
              aria-expanded={open}
              onClick={() => setOpen((v) => !v)}
            >
              {open ? <X className="size-5" /> : <Menu className="size-5" />}
            </button>
          </div>
        </div>
      </div>

      {open ? (
        <div className="fixed inset-0 top-[4.5rem] z-40 bg-paper lg:hidden">
          <nav className="container-site flex h-full flex-col gap-1 overflow-y-auto py-6 pb-28">
            {NAV.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className="rounded-lg px-3 py-3 text-base font-semibold text-ink hover:bg-cream"
              >
                {item.label}
              </Link>
            ))}
            <p className="mt-4 px-3 text-xs font-semibold uppercase tracking-[0.16em] text-muted">
              Products
            </p>
            {PRODUCTS.map((p) => (
              <Link
                key={p.slug}
                to="/products/$slug"
                params={{ slug: p.slug }}
                className="rounded-lg px-3 py-3 text-sm text-ink hover:bg-cream"
              >
                {p.name}
              </Link>
            ))}
            <div className="mt-6 flex flex-col gap-3 px-3">
              <Button asChild>
                <Link to="/contact">Get a free quote</Link>
              </Button>
              <Button asChild variant="outline">
                <a href={whatsappUrl()} target="_blank" rel="noreferrer">
                  WhatsApp now
                </a>
              </Button>
            </div>
          </nav>
        </div>
      ) : null}
    </header>
  );
}
